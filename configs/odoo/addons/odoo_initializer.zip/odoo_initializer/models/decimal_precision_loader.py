from .base_loader import BaseLoader


class DecimalPrecisionLoader(BaseLoader):
    model_name = "decimal.precision"
    folder = "decimal_precision"
    filters = {}